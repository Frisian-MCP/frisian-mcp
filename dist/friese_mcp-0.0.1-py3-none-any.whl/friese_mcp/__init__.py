"""friese-mcp: Django MCP gateway with runtime introspection and permission-aware tool scoping."""

__version__ = "0.0.1"
